function comments()
{
    var comment = document.querySelector("#id1").value
    var commentBox = document.querySelector("#placecomment").cloneNode(true)

    commentBox.removeAttribute("id")
    commentBox.style.visibility=" visible"
    commentBox.children[0].innerHTML= comment

    var commentDiv = document.querySelector("#CommentDiv")
    commentDiv.insertAfter(commentBox,commentDiv.firstChild)

    document.querySelector("#id1").value=" "
}